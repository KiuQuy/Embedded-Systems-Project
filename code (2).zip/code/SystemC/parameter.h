const int MAX_WEIGHT = 2000;  //kg
/* 
S1: state 1,...
VMAX: max speed
VMIN: min speed
*/

// STATE 1
const int S1_VMAX = 30;
const int S1_VMIN  = 5;

const int S1_SMIN = 0;
const int S1_SMAX = 20;  
//STATE 2
const int S2_VMAX = 50;
const int S2_VMIN  = 20;

const int S2_SMIN = 20;
const int S2_SMAX = 50; 

//STATE 3
const int S3_VMAX = 20;
const int S3_VMIN = 10;

const int S3_SMIN = 50;
const int S3_SMAX = 60; 
//STATE 4
const int S4_VMAX = 30;
const int S4_VMIN = 10;

const int S4_SMIN = 60;
const int S4_SMAX = 100; 