#include "systemc.h"
#include "parameter.h"
#include <ostream>
using namespace sc_core;
/*
SC_MODULE (WEIGHT_SENSOR)
{
        sc_in <int> weight;
        sc_out <bool> alarm_weight;
    SC_CTOR(WEIGHT_SENSOR)
    {
        SC_METHOD(alarm_weight_signal);
	}
    void alarm_weight_signal()
    {
        if(weight.read() > MAX_WEIGHT) alarm_weight.write(1);
        else alarm_weight.write(0);
    }
};

*/
SC_MODULE(TOP_CONTROL)
{
    sc_in_clk    clk;
    sc_in  <int> weight;
    sc_signal  <bool> alarm_signal;
    sc_in  <bool> human_control_signal;
    sc_in  <int> speed;
    sc_in  <int> ir_sensor_signal;
    sc_out < sc_lv<4> > speed_signal;
    sc_out <bool> destination;
	int alarm_weight;

    SC_CTOR(TOP_CONTROL)
    {
        SC_METHOD(send_control_speed_signal);
        SC_METHOD(alarm_weight_signal);
        sensitive << clk.pos();
        sensitive << alarm_signal;
        sensitive << human_control_signal;
    }
    void alarm_weight_signal()
    {
        if(weight.read() > MAX_WEIGHT) alarm_weight = 1;
        else alarm_weight = 0;
    }
	void send_control_speed_signal()
    {
        if(alarm_signal == 1 & human_control_signal == 1)
        {
        switch (ir_sensor_signal.read())
        {
            case 1:
                if(speed.read() < S1_VMIN) speed_signal.write(0010);
                else if (speed.read() > S1_VMAX) speed_signal.write(0100);
                else speed_signal.write(0001);
	        case 2:
	            if(speed.read()< S2_VMIN) speed_signal.write(0010);
		        else if(speed.read() > S2_VMAX ) speed_signal.write(0100);
		        else speed_signal.write(0001);
		
			case 3:
	 		    if(speed.read() < S3_VMIN) speed_signal.write(0010);
				else if(speed.read() > S3_VMAX ) speed_signal.write(0100);
				else speed_signal.write(0001);
			case 4:
	    		if(speed.read() < S4_VMIN) speed_signal.write(0010);
				else if(speed.read() > S4_VMAX ) speed_signal.write(0100);
				else speed_signal.write(0001);
            case 5:
                destination.write(1);
  	    }
        }

    }
};
/*
SC_MODULE (TOP_MODULE)
{

    sc_in <int> weight; 

    sc_in_clk    clk;

    sc_in  <bool> human_control_signal;
    sc_in  <int> speed;
    sc_in  <int> ir_sensor_signal;

    sc_out <sc_lv <4> > speed_signal;
    sc_out <bool> destination;

    sc_signal <int> weight_out;
    sc_signal <bool> alarm_signal;

    SC_CTOR(TOP_MODULE)
    {
    WEIGHT_SENSOR weight_sensor ("weight_sensor");
        weight_sensor.weight(weight);
        weight_sensor.alarm_weight(alarm_signal);
  
    TOP_CONTROL top_control ("top_control");
        top_control.clk(clk);
        top_control.weight(weight);
        top_control.alarm_signal(alarm_signal);
        top_control.human_control_signal(human_control_signal);
        top_control.speed(speed);
        top_control.ir_sensor_signal(ir_sensor_signal);
        top_control.speed_signal(speed_signal);
        top_control.destination(destination);
    }
};
*/

