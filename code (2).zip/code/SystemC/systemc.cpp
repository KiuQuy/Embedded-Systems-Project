#include "systemc.h"
#include <ostream>
using namespace sc_core;
const int MAX_WEIGHT = 2000;  //kg
/* 
S1: state 1,...
VMAX: max speed
VMIN: min speed
*/

 

// STATE 1
const int S1_VMAX = 30;
const int S1_VMIN  = 5;

 

const int S1_SMIN = 0;
const int S1_SMAX = 20;  
//STATE 2
const int S2_VMAX = 50;
const int S2_VMIN  = 20;

 

const int S2_SMIN = 20;
const int S2_SMAX = 50;

 

//STATE 3
const int S3_VMAX = 20;
const int S3_VMIN = 10;

 

const int S3_SMIN = 50;
const int S3_SMAX = 60; 
//STATE 4
const int S4_VMAX = 30;
const int S4_VMIN = 10;

 

const int S4_SMIN = 60;
const int S4_SMAX = 100;

 


SC_MODULE (CLOCK)
{
    sc_port <sc_signal_in_if<bool>> clk;  // aport yo access clock
    SC_CTOR(CLOCK)
    {
        SC_THREAD(thread); // register a thread process
        sensitive << clk;  // sensitive to clock
        dont_initialize();
    }
    void thread()
    {
        while(true)
        {
            std::cout << sc_time_stamp() << ", value = " << clk -> read() << std::endl;
            wait(); // wait for next clock value change
        }
    }

};

 


SC_MODULE(GET_SIGNAL)
{
    sc_in<bool>  clk;
    sc_in <int> speed;
    sc_in <int> distance;
    sc_out <int>  speed_signal; // 0001: un change; 0010: speed up, 0100: speed down; 1000: imer
    sc_out <int> state;

   // sc_uint<3> state;  // local variables 

    void write_signal()
    {
    if(distance.read() > S1_SMIN && distance.read() <= S1_SMAX) state.write(1);
    else if (distance.read() <= S2_SMAX) state.write(2);
    else if (distance.read() <= S3_SMAX) state.write(3);
    else  state.write(4);    

    switch (state)
    {
    case 1:
        if(speed.read() < S1_VMIN) speed_signal.write(2);
        else if (speed.read() > S1_VMAX) speed_signal.write(8);
        else speed_signal.write(1);
    case 2:
        if(speed.read()< S2_VMIN) speed_signal.write(2);
        else if(speed.read() > S2_VMAX ) speed_signal.write(8);
        else speed_signal.write(1);

    case 3:
        if(speed.read() < S3_VMIN) speed_signal.write(2);
        else if(speed.read() > S3_VMAX ) speed_signal.write(8);
        else speed_signal.write(1);
    case 4:
        if(speed.read() < S4_VMIN) speed_signal.write(2);
        else if(speed.read() > S4_VMAX ) speed_signal.write(8);
        else speed_signal.write(1);   
    }
    cout << sc_time_stamp() << "   speed: " << speed.read() << "    state: " << state.read() << "    distance: " << distance.read();
      if (speed_signal.read() == 8) cout << " => send speed_up signal" << endl;
      else if (speed_signal.read() == 2) cout << " => send speed_down signal" << endl;
      else cout << " => send unchange_speed signal" << endl;
    }

  SC_CTOR(GET_SIGNAL)
  {
    cout << "Bat dau" << endl;
    SC_METHOD(write_signal);

    sensitive << clk.pos();
  }
};

 


int sc_main (int, char*[])
{
    sc_clock clk ("clk",1, SC_MS, 0.05, 0, SC_MS, false);
    // period = 1 ms, 0.5ms true, 0.5ms false, start at 0ms, start at false


    CLOCK clock ("clock");     // instance module

    clock.clk(clk); // bind port

    sc_signal <int> speed;
    sc_signal <int> distance;
    sc_signal <int>  speed_signal; // 0001: un change; 0010: speed up, 0100: speed down; 1000: imer
    sc_signal <int> state;

  // connect the DUT
    GET_SIGNAL get_signal_inst ("GET_SIGNAL_INST");

    get_signal_inst.clk(clk);
    get_signal_inst.speed(speed);
    get_signal_inst.distance(distance);  
    get_signal_inst.speed_signal(speed_signal);
    get_signal_inst.state(state);   
        speed = 50;
      distance = 60;
    sc_start(20, SC_MS);


    return 0;
}